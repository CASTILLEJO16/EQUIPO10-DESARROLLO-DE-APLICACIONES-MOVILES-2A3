import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Image,
} from 'react-native';

export default function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.logo}>⚡ POKÉDEX ⚡</Text>
        <Text style={styles.subtitle}>Aplicación Móvil</Text>
      </View>

      <View style={styles.imageContainer}>
        <Text style={styles.pokeball}>⚪</Text>
      </View>

      <View style={styles.infoCard}>
        <Text style={styles.infoTitle}>👥 Integrantes</Text>
        
        <View style={styles.memberCard}>
          <Text style={styles.memberName}>
            Castillejo Robles Lennyn Alejandro
          </Text>
        </View>
        
        <View style={styles.memberCard}>
          <Text style={styles.memberName}>
            Orozco Hernández Brandon
          </Text>
        </View>

        <View style={styles.divider} />

        <Text style={styles.infoTitle}>📚 Materia</Text>
        <Text style={styles.subject}>Desarrollo de Aplicaciones</Text>
      </View>

      <TouchableOpacity 
        style={styles.button}
        onPress={() => navigation.navigate('Main')}
      >
        <Text style={styles.buttonText}>Iniciar Pokédex</Text>
      </TouchableOpacity>

      <Text style={styles.footer}>Powered by PokéAPI</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#e74c3c',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  header: {
    alignItems: 'center',
    marginBottom: 30,
  },
  logo: {
    fontSize: 42,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 18,
    color: 'rgba(255,255,255,0.9)',
    fontWeight: '600',
  },
  imageContainer: {
    marginBottom: 30,
  },
  pokeball: {
    fontSize: 100,
  },
  infoCard: {
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 25,
    width: '100%',
    marginBottom: 30,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  infoTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#2c3e50',
    marginBottom: 15,
    textAlign: 'center',
  },
  memberCard: {
    backgroundColor: '#ecf0f1',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
  },
  memberName: {
    fontSize: 16,
    color: '#34495e',
    textAlign: 'center',
    fontWeight: '500',
  },
  divider: {
    height: 2,
    backgroundColor: '#ecf0f1',
    marginVertical: 20,
  },
  subject: {
    fontSize: 18,
    color: '#e74c3c',
    textAlign: 'center',
    fontWeight: 'bold',
  },
  button: {
    backgroundColor: 'white',
    paddingVertical: 18,
    paddingHorizontal: 50,
    borderRadius: 30,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  buttonText: {
    color: '#e74c3c',
    fontSize: 20,
    fontWeight: 'bold',
  },
  footer: {
    marginTop: 20,
    color: 'rgba(255,255,255,0.7)',
    fontSize: 14,
  },
});