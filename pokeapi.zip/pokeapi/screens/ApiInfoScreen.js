import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  ActivityIndicator,
  StyleSheet,
} from 'react-native';

const POKEAPI_URL = "https://pokeapi.co/api/v2";

export default function ApiInfoScreen() {
  const [apiStats, setApiStats] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadApiInfo = async () => {
      try {
        // Obtener información general de la API
        const pokemonRes = await fetch(`${POKEAPI_URL}/pokemon?limit=1`);
        const pokemonData = await pokemonRes.json();

        const typesRes = await fetch(`${POKEAPI_URL}/type`);
        const typesData = await typesRes.json();

        const movesRes = await fetch(`${POKEAPI_URL}/move?limit=1`);
        const movesData = await movesRes.json();

        const abilitiesRes = await fetch(`${POKEAPI_URL}/ability?limit=1`);
        const abilitiesData = await abilitiesRes.json();

        setApiStats({
          totalPokemon: pokemonData.count,
          totalTypes: typesData.count,
          totalMoves: movesData.count,
          totalAbilities: abilitiesData.count,
        });
        setIsLoading(false);
      } catch (error) {
        console.error("Error al cargar información de la API:", error);
        setIsLoading(false);
      }
    };
    loadApiInfo();
  }, []);

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#e74c3c" />
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>📋 Información de PokéAPI</Text>
        <Text style={styles.subtitle}>Datos y Estadísticas</Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>🌐 Acerca de la API</Text>
        <Text style={styles.cardText}>
          PokéAPI es una API RESTful gratuita que proporciona información 
          completa sobre el universo Pokémon.
        </Text>
        <View style={styles.infoRow}>
          <Text style={styles.label}>URL Base:</Text>
          <Text style={styles.value}>https://pokeapi.co/api/v2</Text>
        </View>
        <View style={styles.infoRow}>
          <Text style={styles.label}>Versión:</Text>
          <Text style={styles.value}>v2</Text>
        </View>
        <View style={styles.infoRow}>
          <Text style={styles.label}>Formato:</Text>
          <Text style={styles.value}>JSON</Text>
        </View>
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>📊 Estadísticas</Text>
        
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>{apiStats?.totalPokemon || 0}</Text>
          <Text style={styles.statLabel}>Pokémon Totales</Text>
        </View>

        <View style={styles.statCard}>
          <Text style={styles.statNumber}>{apiStats?.totalTypes || 0}</Text>
          <Text style={styles.statLabel}>Tipos de Pokémon</Text>
        </View>

        <View style={styles.statCard}>
          <Text style={styles.statNumber}>{apiStats?.totalMoves || 0}</Text>
          <Text style={styles.statLabel}>Movimientos</Text>
        </View>

        <View style={styles.statCard}>
          <Text style={styles.statNumber}>{apiStats?.totalAbilities || 0}</Text>
          <Text style={styles.statLabel}>Habilidades</Text>
        </View>
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>🔧 Endpoints Principales</Text>
        
        <View style={styles.endpointCard}>
          <Text style={styles.endpoint}>/pokemon</Text>
          <Text style={styles.endpointDesc}>
            Lista y detalles de todos los Pokémon
          </Text>
        </View>

        <View style={styles.endpointCard}>
          <Text style={styles.endpoint}>/pokemon-species</Text>
          <Text style={styles.endpointDesc}>
            Información de especies y descripciones
          </Text>
        </View>

        <View style={styles.endpointCard}>
          <Text style={styles.endpoint}>/type</Text>
          <Text style={styles.endpointDesc}>
            Tipos de Pokémon y sus relaciones
          </Text>
        </View>

        <View style={styles.endpointCard}>
          <Text style={styles.endpoint}>/ability</Text>
          <Text style={styles.endpointDesc}>
            Habilidades de los Pokémon
          </Text>
        </View>

        <View style={styles.endpointCard}>
          <Text style={styles.endpoint}>/move</Text>
          <Text style={styles.endpointDesc}>
            Movimientos y ataques disponibles
          </Text>
        </View>
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>⚡ Características</Text>
        <View style={styles.featureItem}>
          <Text style={styles.bullet}>✓</Text>
          <Text style={styles.featureText}>API completamente gratuita</Text>
        </View>
        <View style={styles.featureItem}>
          <Text style={styles.bullet}>✓</Text>
          <Text style={styles.featureText}>No requiere autenticación</Text>
        </View>
        <View style={styles.featureItem}>
          <Text style={styles.bullet}>✓</Text>
          <Text style={styles.featureText}>Datos en múltiples idiomas</Text>
        </View>
        <View style={styles.featureItem}>
          <Text style={styles.bullet}>✓</Text>
          <Text style={styles.featureText}>Imágenes oficiales de alta calidad</Text>
        </View>
        <View style={styles.featureItem}>
          <Text style={styles.bullet}>✓</Text>
          <Text style={styles.featureText}>Actualización constante</Text>
        </View>
      </View>

      <View style={styles.footer}>
        <Text style={styles.footerText}>
          Esta aplicación consume datos de PokéAPI
        </Text>
        <Text style={styles.footerLink}>
          pokeapi.co
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ecf0f1',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#ecf0f1',
  },
  header: {
    backgroundColor: '#e74c3c',
    padding: 30,
    alignItems: 'center',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 16,
    color: 'rgba(255,255,255,0.9)',
  },
  card: {
    backgroundColor: 'white',
    margin: 15,
    padding: 20,
    borderRadius: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  cardTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#2c3e50',
    marginBottom: 15,
  },
  cardText: {
    fontSize: 15,
    color: '#34495e',
    lineHeight: 22,
    marginBottom: 15,
  },
  infoRow: {
    flexDirection: 'row',
    marginBottom: 10,
  },
  label: {
    fontSize: 15,
    fontWeight: '600',
    color: '#2c3e50',
    width: 100,
  },
  value: {
    fontSize: 15,
    color: '#7f8c8d',
    flex: 1,
  },
  statCard: {
    backgroundColor: '#ecf0f1',
    padding: 20,
    borderRadius: 10,
    marginBottom: 10,
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 36,
    fontWeight: 'bold',
    color: '#e74c3c',
    marginBottom: 5,
  },
  statLabel: {
    fontSize: 16,
    color: '#34495e',
  },
  endpointCard: {
    backgroundColor: '#ecf0f1',
    padding: 15,
    borderRadius: 8,
    marginBottom: 10,
  },
  endpoint: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#e74c3c',
    marginBottom: 5,
    fontFamily: 'monospace',
  },
  endpointDesc: {
    fontSize: 14,
    color: '#34495e',
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  bullet: {
    fontSize: 18,
    color: '#27ae60',
    marginRight: 10,
    fontWeight: 'bold',
  },
  featureText: {
    fontSize: 15,
    color: '#34495e',
    flex: 1,
  },
  footer: {
    alignItems: 'center',
    padding: 20,
    marginBottom: 20,
  },
  footerText: {
    fontSize: 14,
    color: '#7f8c8d',
    marginBottom: 5,
  },
  footerLink: {
    fontSize: 16,
    color: '#e74c3c',
    fontWeight: 'bold',
  },
});