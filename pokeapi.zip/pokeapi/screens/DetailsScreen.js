import React from 'react';
import {
  View,
  Text,
  ScrollView,
  Image,
  StyleSheet,
} from 'react-native';

export default function DetailsScreen({ route }) {
  const { pokemon } = route.params;

  return (
    <ScrollView style={styles.container}>
      <View style={styles.detailsCard}>
        <Image 
          style={styles.detailsImage} 
          source={{ uri: pokemon.image }} 
        />
        <Text style={styles.detailsTitle}>{pokemon.name}</Text>
        <Text style={styles.detailsId}>#{pokemon.id}</Text>
        
        <View style={styles.infoSection}>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Tipo:</Text>
            <Text style={styles.infoValue}>{pokemon.types}</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Altura:</Text>
            <Text style={styles.infoValue}>{pokemon.height} m</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Peso:</Text>
            <Text style={styles.infoValue}>{pokemon.weight} kg</Text>
          </View>
        </View>

        <Text style={styles.sectionTitle}>Descripción</Text>
        <Text style={styles.description}>{pokemon.description}</Text>

        <Text style={styles.sectionTitle}>Estadísticas</Text>
        {pokemon.stats?.map((stat, idx) => (
          <View key={idx} style={styles.statRow}>
            <Text style={styles.statName}>{stat.stat.name}:</Text>
            <View style={styles.statBar}>
              <View 
                style={[
                  styles.statFill, 
                  { width: `${(stat.base_stat / 255) * 100}%` }
                ]} 
              />
            </View>
            <Text style={styles.statValue}>{stat.base_stat}</Text>
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ecf0f1',
  },
  detailsCard: {
    backgroundColor: 'white',
    borderRadius: 15,
    padding: 25,
    margin: 20,
    alignItems: 'center',
  },
  detailsImage: {
    width: 200,
    height: 200,
    marginBottom: 20,
  },
  detailsTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#2c3e50',
    marginBottom: 5,
  },
  detailsId: {
    fontSize: 18,
    color: '#7f8c8d',
    marginBottom: 20,
  },
  infoSection: {
    width: '100%',
    marginBottom: 20,
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ecf0f1',
  },
  infoLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#34495e',
  },
  infoValue: {
    fontSize: 16,
    color: '#7f8c8d',
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#2c3e50',
    marginTop: 20,
    marginBottom: 10,
    width: '100%',
  },
  description: {
    fontSize: 15,
    color: '#34495e',
    lineHeight: 22,
    textAlign: 'center',
    marginBottom: 20,
  },
  statRow: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '100%',
    marginBottom: 8,
  },
  statName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#34495e',
    width: 120,
    textTransform: 'capitalize',
  },
  statBar: {
    flex: 1,
    height: 20,
    backgroundColor: '#ecf0f1',
    borderRadius: 10,
    marginRight: 10,
    overflow: 'hidden',
  },
  statFill: {
    height: '100%',
    backgroundColor: '#e74c3c',
  },
  statValue: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#2c3e50',
    width: 40,
    textAlign: 'right',
  },
});