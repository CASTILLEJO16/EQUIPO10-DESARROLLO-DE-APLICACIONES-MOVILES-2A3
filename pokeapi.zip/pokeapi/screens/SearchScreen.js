import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  ScrollView,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  StyleSheet,
} from 'react-native';

const POKEAPI_URL = "https://pokeapi.co/api/v2";

export default function SearchScreen({ navigation }) {
  const [pokemonList, setPokemonList] = useState([]);
  const [searchText, setSearchText] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const latestSearchId = useRef(0);

  useEffect(() => {
    const loadInitialData = async () => {
      try {
        const res = await fetch(`${POKEAPI_URL}/pokemon?limit=2000`);
        const data = await res.json();
        setPokemonList(data.results);
      } catch (error) {
        console.error("Error al cargar Pokémon:", error);
      }
    };
    loadInitialData();
  }, []);

  const performSearch = useCallback(async (text) => {
    const cleanedText = text.toLowerCase().trim();
    
    if (cleanedText.length < 2) {
      setSearchResults([]);
      setIsLoading(false);
      return;
    }

    const currentSearchId = ++latestSearchId.current;
    setIsLoading(true);
    setSearchResults([]);

    let matches;
    const isNumeric = /^\d+$/.test(cleanedText);

    if (isNumeric) {
      matches = pokemonList.filter(p => {
        const id = p.url.split("/").slice(-2, -1)[0];
        return id === cleanedText;
      });
    } else {
      matches = pokemonList.filter(p => p.name.includes(cleanedText));
    }

    const detailedResults = [];

    for (const p of matches.slice(0, 20)) {
      if (currentSearchId !== latestSearchId.current) return;

      try {
        const res = await fetch(p.url);
        const info = await res.json();

        const spRes = await fetch(`${POKEAPI_URL}/pokemon-species/${info.id}`);
        const spData = await spRes.json();

        const nombreEsp = spData.names.find(n => n.language.name === "es")?.name || info.name;
        const descripcionEsp = spData.flavor_text_entries
          .find(d => d.language.name === "es")
          ?.flavor_text.replace(/\n|\f/g, " ") || "Sin descripción disponible.";

        detailedResults.push({
          id: info.id,
          name: nombreEsp,
          image: info.sprites.other['official-artwork'].front_default,
          types: info.types.map(t => t.type.name).join(", "),
          height: info.height / 10,
          weight: info.weight / 10,
          description: descripcionEsp,
          stats: info.stats,
          abilities: info.abilities
        });

        if (currentSearchId === latestSearchId.current) {
          setSearchResults([...detailedResults]);
        }
      } catch (error) {
        console.error(`Error:`, error);
      }
    }

    if (currentSearchId === latestSearchId.current) {
      setIsLoading(false);
    }
  }, [pokemonList]);

  useEffect(() => {
    if (pokemonList.length > 0) {
      performSearch(searchText);
    }
  }, [searchText, pokemonList, performSearch]);

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="Buscar por nombre o ID..."
        value={searchText}
        onChangeText={setSearchText}
      />

      {isLoading && <ActivityIndicator size="large" color="#e74c3c" />}

      <ScrollView style={styles.scrollView}>
        {searchResults.map(p => (
          <TouchableOpacity 
            key={p.id} 
            style={styles.card}
            onPress={() => navigation.navigate('Details', { pokemon: p })}
          >
            <Image 
              style={styles.cardImage} 
              source={{ uri: p.image }} 
            />
            <View style={styles.cardContent}>
              <Text style={styles.cardTitle}>{p.name}</Text>
              <Text style={styles.cardSubtitle}>#{p.id} • {p.types}</Text>
            </View>
          </TouchableOpacity>
        ))}

        {!isLoading && searchText.length >= 2 && searchResults.length === 0 && (
          <Text style={styles.noResults}>No se encontraron resultados</Text>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ecf0f1',
    padding: 20,
  },
  input: {
    padding: 15,
    fontSize: 16,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: '#bdc3c7',
    marginBottom: 20,
    backgroundColor: 'white',
  },
  scrollView: {
    flex: 1,
  },
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 15,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  cardImage: {
    width: 70,
    height: 70,
    marginRight: 15,
  },
  cardContent: {
    flex: 1,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2c3e50',
    marginBottom: 5,
  },
  cardSubtitle: {
    fontSize: 14,
    color: '#7f8c8d',
  },
  noResults: {
    textAlign: 'center',
    fontSize: 16,
    color: '#95a5a6',
    marginTop: 40,
  },
});
