import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  ActivityIndicator,
  StyleSheet,
} from 'react-native';

const POKEAPI_URL = "https://pokeapi.co/api/v2";

export default function TypeDetailScreen({ route }) {
  const { typeName } = route.params;
  const [pokemonOfType, setPokemonOfType] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadTypeDetails = async () => {
      try {
        const res = await fetch(`${POKEAPI_URL}/type/${typeName}`);
        const data = await res.json();
        
        const pokemonList = data.pokemon.slice(0, 30).map(p => ({
          name: p.pokemon.name,
          url: p.pokemon.url,
          id: p.pokemon.url.split('/').slice(-2, -1)[0]
        }));
        
        setPokemonOfType(pokemonList);
        setIsLoading(false);
      } catch (error) {
        console.error("Error:", error);
        setIsLoading(false);
      }
    };
    loadTypeDetails();
  }, [typeName]);

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#e74c3c" />
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerText}>
          Tipo: {typeName.toUpperCase()}
        </Text>
        <Text style={styles.subHeaderText}>
          {pokemonOfType.length} Pokémon
        </Text>
      </View>

      {pokemonOfType.map((p) => (
        <View key={p.id} style={styles.pokemonCard}>
          <Text style={styles.pokemonId}>#{p.id}</Text>
          <Text style={styles.pokemonName}>{p.name}</Text>
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ecf0f1',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#ecf0f1',
  },
  header: {
    backgroundColor: 'white',
    padding: 20,
    marginBottom: 10,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#2c3e50',
    marginBottom: 5,
  },
  subHeaderText: {
    fontSize: 16,
    color: '#7f8c8d',
  },
  pokemonCard: {
    flexDirection: 'row',
    backgroundColor: 'white',
    padding: 15,
    marginHorizontal: 20,
    marginBottom: 10,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  pokemonId: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#7f8c8d',
    marginRight: 15,
  },
  pokemonName: {
    fontSize: 16,
    color: '#2c3e50',
    textTransform: 'capitalize',
  },
});