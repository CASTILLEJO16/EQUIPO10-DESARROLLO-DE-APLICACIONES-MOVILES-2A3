  import React from 'react';
  import { createStackNavigator } from '@react-navigation/stack';
  import TypesScreen from '../screens/TypesScreen';
  import TypeDetailScreen from '../screens/TypeDetailScreen';

  const Stack = createStackNavigator();

  export default function TypesNavigator() {
    return (
      <Stack.Navigator>
        <Stack.Screen 
          name="Types" 
          component={TypesScreen}
          options={{ title: 'Tipos de Pokémon' }}
        />
        <Stack.Screen 
          name="TypeDetail" 
          component={TypeDetailScreen}
          options={{ title: 'Pokémon del Tipo' }}
        />
      </Stack.Navigator>
    );
  }