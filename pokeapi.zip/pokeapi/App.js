import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import HomeScreen from './screens/HomeScreen';
import SearchNavigator from './navigators/StackNavigator';
import TypesNavigator from './navigators/BottomTabNavigator';
import ApiInfoScreen from './screens/ApiInfoScreen';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={{
        tabBarActiveTintColor: '#e74c3c',
        tabBarInactiveTintColor: '#7f8c8d',
        headerShown: false,
      }}
    >
      <Tab.Screen 
        name="SearchTab" 
        component={SearchNavigator}
        options={{
          tabBarLabel: 'Buscar',
          tabBarIcon: () => '🔍',
        }}
      />
      <Tab.Screen 
        name="TypesTab" 
        component={TypesNavigator}
        options={{
          tabBarLabel: 'Tipos',
          tabBarIcon: () => '⚡',
        }}
      />
      <Tab.Screen 
        name="ApiInfoTab" 
        component={ApiInfoScreen}
        options={{
          tabBarLabel: 'Info API',
          tabBarIcon: () => '📋',
        }}
      />
    </Tab.Navigator>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Main" component={MainTabs} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}